package selinturan.com.a335secondmidterm;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.TextView;

public class Position extends Activity implements LocationListener {


    private LocationManager locManager;
    private Location myLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Criteria criteria = new Criteria();
        criteria.setCostAllowed(false);
        locManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling

            return;
        }
        locManager.requestLocationUpdates(locManager.getBestProvider(criteria, true), 10, 40, this);

        Log.d("Location", locManager.getBestProvider(criteria, true));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        locManager.removeUpdates(this);
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d("Location", "Lat : " + location.getLatitude() + " Lon : " + location.getLongitude());
        myLocation = location;
        ((TextView)findViewById(R.id.loc)).setText("Lat : " + location.getLatitude() + " Lon : " + location.getLongitude());
    }

    @Override
    public void onProviderDisabled(String arg0) {

    }

    @Override
    public void onProviderEnabled(String arg0) {

    }

    @Override
    public void onStatusChanged(String arg0, int arg1, Bundle arg2) {

    }

}
