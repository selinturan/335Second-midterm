package selinturan.com.a335secondmidterm;


import android.location.Location;
import android.location.LocationManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.net.HttpURLConnection;
import java.net.URL;

import static android.content.ContentValues.TAG;

public class FoursquareApp {
    public static final String CALLBACK_URL = "https://335SecondMidterm.com";
    private static final String AUTH_URL = "https://foursquare.com/oauth2/authenticate?response_type=code";
    private static final String TOKEN_URL = "https://foursquare.com/oauth2/access_token?grant_type=authorization_code";
    private static final String API_URL = "https://api.foursquare.com/v2";

    public ArrayList<FsqVenue> getNearby(double latitude, double longitude) throws Exception {
    ArrayList<FsqVenue> venueList = new ArrayList<FsqVenue>();

        try {
            String ll = String.valueOf(latitude) + "," + String.valueOf(longitude);

            URL url = new URL(API_URL + "/venues/search?ll=" + ll + "&oauth_token=" + mAccessToken);

          Log.d(TAG, "Opening URL " + url.toString());


            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

            urlConnection.setRequestMethod("GET");
          urlConnection.setDoInput(true);
          urlConnection.setDoOutput(true);

          urlConnection.connect();

 String response= streamToString(urlConnection.getInputStream());
JSONObject jsonObj= (JSONObject)new JSONTokener(response).nextValue();
    JSONArray groups;
            groups = (JSONArray) jsonObj.getJSONObject("response").getJSONArray("groups");

     int length= groups.length();


            if (length > 0) {

                for (int i = 0; i < length; i++) {

                    JSONObject group= (JSONObject) groups.get(i);
                    JSONArray items= (JSONArray) group.getJSONArray("items");

                  int ilength= items.length();

                   for (int j = 0; j < ilength; j++) {
                   JSONObject item = (JSONObject) items.get(j);

                   FsqVenue venue= new FsqVenue();

                     venue.id= item.getString("id");
                        venue.name      = item.getString("name");
 
                        JSONObject location = (JSONObject) item.getJSONObject("location");
 
                        Location loc    = new Location(LocationManager.GPS_PROVIDER);
 
                        loc.setLatitude(Double.valueOf(location.getString("lat")));
                        loc.setLongitude(Double.valueOf(location.getString("lng")));
 
                        venue.location  = loc;
                        venue.address   = location.getString("address");
                        venue.distance  = location.getInt("distance");
                        venue.herenow   = item.getJSONObject("hereNow").getInt("count");
                        venue.type      = group.getString("type");
 
                        venueList.add(venue);
                    }
                }

} catch (Exception ex) {
throw ex;
}
return venueList;
}





}
